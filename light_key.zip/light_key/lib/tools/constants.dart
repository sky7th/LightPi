import 'package:flutter/material.dart';

const kTopBottomColor = Color(0xFF35477d);
const kHomePageCardColor = Color(0xFF5782bb);
//const kTopBottomColor = Color(0xFF34699a);
const kNoItemTextStyle = TextStyle(fontSize: 16);
